package com.example.messengerapp2


import android.app.Activity
import android.content.Intent
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        RegbuttReg.setOnClickListener {
           performRegister()
        }

        textSwitchReg.setOnClickListener {
            Log.d("MainActivity","Try to show login activity")
            val intent=Intent(this, LoginActivity::class.java)
            startActivity(intent)

        }
        selectphoto.setOnClickListener{
            Log.d("MainActivity","Try to show photo selector")
            val intent=Intent(Intent.ACTION_PICK)
            intent.type="image/*"
           startActivityForResult(intent,0)
        }


    }
 var selectedPhotoUri : Uri? =null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode==0 && resultCode==Activity.RESULT_OK && data!=null){


            Log.d("MainActivity","Photo was selected")
           selectedPhotoUri= data.data
            val bitmap=MediaStore.Images.Media.getBitmap(
                contentResolver,
                selectedPhotoUri
            )
            val bitmapDrawable=BitmapDrawable(bitmap)
            selectphoto.setBackgroundDrawable(bitmapDrawable)

        }
    }
    private  fun performRegister(){
        val email= etEmailReg.text.toString()
        val pass = etPassReg.text.toString()
        if(email.isEmpty() ||pass.isEmpty()) {

            Toast.makeText(this,"please enter text in email",Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("MainActivity","Email : "+email)
        Log.d("MainActivity","Password : $pass")
        //firebase
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email,pass)
            .addOnCompleteListener{

                if (!it.isSuccessful) return@addOnCompleteListener
                Log.d("Main","Successfully created user with uid : ${it.result.user?.uid}")
       uploadimagetofirestore()

            }
            .addOnFailureListener{

                Log.d("Main","Failed to create user : ${it.message}")
                Toast.makeText(this,"Failed to create user : ${it.message}",Toast.LENGTH_SHORT).show()


            }

    }
    private fun  uploadimagetofirestore(){
if (selectedPhotoUri ==null)return

val filename= UUID.randomUUID().toString()
        val ref =FirebaseStorage.getInstance().getReference("/images/$filename")

        ref.putFile(selectedPhotoUri!!).addOnSuccessListener {
            Log.d("MainActivity","Successfully Uploaded Picture: ${it.metadata?.path}")
            ref.downloadUrl.addOnSuccessListener {
                Log.d("MainActivity","File LOcation: $it")
                saveusertofire(it.toString())

            }

        }
            .addOnFailureListener({

            })


    }
       private fun saveusertofire(profileImageUrl: String){
           val uid=FirebaseAuth.getInstance().uid ?:""
           val ref= FirebaseDatabase.getInstance().getReference("/users/$uid")
           val user=User(uid,etUserReg.text.toString(),profileImageUrl)
           ref.setValue(user).addOnSuccessListener {

               Log.d("MainActivity","Finally we saved the user to database")
           }


       }
}
class User(val uid:String,val username:String, val profileImageUrl: String)